from django.apps import AppConfig


class BatableConfig(AppConfig):
    name = 'BATable'
