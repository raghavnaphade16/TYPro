#!/bin/bash

zip -r vaadin-icons-png.zip png
zip -r vaadin-icons-svg.zip svg
zip -r vaadin-icons.zip fonts
