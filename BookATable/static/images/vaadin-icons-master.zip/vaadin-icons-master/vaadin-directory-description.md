
# Vaadin Icons

[![Available in Vaadin_Directory](https://img.shields.io/vaadin-directory/v/vaadinvaadin-icons.svg)](https://vaadin.com/directory/component/vaadinvaadin-icons)

[Vaadin Icons](https://vaadin.com/icons) is a set of 600+ icons designed for web applications. Free to use, anywhere!

[<img src="https://raw.github.com/vaadin/vaadin-icons/master/screenshot.png" width="611" alt="Screenshot of some icons in the Vaadin Icons collection" />](https://vaadin.com/icons)


## Example Usage
```html
<iron-icon icon="vaadin:check-square"></iron-icon>
```

